<?php $__env->startSection('page-title', 'Modifier le projet'); ?>
<?php $__env->startSection('content'); ?>
<div class="card card-stat p-4" style="max-width:900px;">
    <h5 class="fw-bold mb-3">Modifier le projet</h5>
    <form method="POST" action="<?php echo e(route('projets.update', $projet)); ?>">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('projets.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="d-flex justify-content-center gap-3 mt-4">
        <button class="btn btn-brand">Mettre à jour</button>
        <a href="<?php echo e(route('projets.show', $projet)); ?>" class="btn btn-outline-secondary">Annuler</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/projets/edit.blade.php ENDPATH**/ ?>