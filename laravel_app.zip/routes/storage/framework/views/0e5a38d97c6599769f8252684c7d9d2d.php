<?php $__env->startSection('page-title', 'Nouveau projet'); ?>

<?php $__env->startSection('content'); ?>
<div class="card card-stat p-4" style="max-width:900px;">
    <h5 class="fw-bold mb-3">Nouveau projet d'investissement public</h5>

    <form method="POST" action="<?php echo e(route('projets.store')); ?>">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('projets.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="d-flex justify-content-center gap-3 mt-4">
            <button type="submit" class="btn btn-brand">
                Enregistrer
            </button>

            <a href="<?php echo e(route('projets.index')); ?>" class="btn btn-outline-secondary">
                Annuler
            </a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mr JOHNNY\Desktop\LARAVEL13\sgspip\resources\views/projets/create.blade.php ENDPATH**/ ?>