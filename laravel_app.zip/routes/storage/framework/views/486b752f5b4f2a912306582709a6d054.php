
<?php
    $defs = \App\Support\FicheVolets::definitions();
    $cles = $only ?? array_keys($defs);
    $marchesProjet = $projet->marches()->orderBy('id')->get();
    $lectureSeule = optional(auth()->user())->role === 'consultant';
    $uid = 'volets-'.substr(md5(implode(',', $cles)), 0, 6);
    $formater = function ($c, $ligne) {
        $v = $ligne->{$c['name']} ?? null;
        if ($v === null || $v === '') { return '—'; }
        if ($c['type'] === 'select') { return $c['options'][$v] ?? $v; }
        if ($c['type'] === 'marche') { return optional($ligne->marche)->objet ?? '—'; }
        if ($c['type'] === 'year') { return $v; }
        if ($c['type'] === 'number') {
            return str_starts_with($c['name'], 'taux_') ? number_format((float) $v, 0, ',', ' ').' %' : number_format((float) $v, 0, ',', ' ');
        }
        return \Illuminate\Support\Str::limit($v, 60);
    };
?>
<style>
    #<?php echo e($uid); ?> .accordion-item { border: 1px solid #eef0f3; border-radius: .9rem !important; margin-bottom: .6rem; overflow: hidden; }
    #<?php echo e($uid); ?> .accordion-button { font-weight: 600; }
    #<?php echo e($uid); ?> .accordion-button:not(.collapsed) { background: #FFF3E6; color: #E06E00; box-shadow: none; }
    #<?php echo e($uid); ?> .accordion-button:focus { box-shadow: 0 0 0 .2rem rgba(255,130,0,.2); }
    #<?php echo e($uid); ?> .accordion-button .badge { background: #FF8200 !important; }
</style>
<div class="accordion mb-3" id="<?php echo e($uid); ?>">
<?php $__currentLoopData = $cles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $def = $defs[$cle];
        $lignes = $def['scope'] === 'projet'
            ? $def['model']::where('projet_id', $projet->id)->orderBy('id')->get()
            : $def['model']::whereIn('marche_id', $marchesProjet->pluck('id'))->with('marche')->orderBy('id')->get();
        $champsAffiches = collect($def['champs'])->whereIn('name', $def['colonnes'])->sortBy(fn ($c) => array_search($c['name'], $def['colonnes']))->values();
        $besoinMarche = collect($def['champs'])->contains('type', 'marche') && $marchesProjet->isEmpty();
    ?>
    <div class="accordion-item">
        <h2 class="accordion-header">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($uid); ?>-<?php echo e($cle); ?>">
                <?php echo e($def['titre']); ?> <span class="badge bg-secondary ms-2"><?php echo e($lignes->count()); ?></span>
            </button>
        </h2>
        <div id="<?php echo e($uid); ?>-<?php echo e($cle); ?>" class="accordion-collapse collapse" data-bs-parent="#<?php echo e($uid); ?>">
            <div class="accordion-body">
                <p class="text-muted small"><?php echo e($def['aide']); ?></p>

                <?php if($lignes->isEmpty()): ?>
                    <p class="text-muted fst-italic">Aucune ligne enregistrée.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm align-middle">
                            <thead><tr>
                                <?php $__currentLoopData = $champsAffiches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($c['label']); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if (! ($lectureSeule)): ?><th style="width:110px"></th><?php endif; ?>
                            </tr></thead>
                            <tbody>
                            <?php $__currentLoopData = $lignes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ligne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php $__currentLoopData = $champsAffiches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><td><?php echo e($formater($c, $ligne)); ?></td><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if (! ($lectureSeule)): ?>
                                    <td class="text-end text-nowrap">
                                        <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#<?php echo e($uid); ?>-<?php echo e($cle); ?>-edit-<?php echo e($ligne->id); ?>" title="Modifier"><i class="bi bi-pencil"></i></button>
                                        <form method="POST" action="<?php echo e(route('fiche.destroy', [$cle, $ligne->id])); ?>" class="d-inline" onsubmit="return confirm('Supprimer cette ligne ?');">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-outline-danger" title="Supprimer"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>

                <?php if (! ($lectureSeule)): ?>
                    <?php if($besoinMarche): ?>
                        <div class="alert alert-info py-2 mb-0">Enregistrez d'abord un marché (volet « Marchés ») pour pouvoir saisir son échéancier.</div>
                    <?php else: ?>
                        <button class="btn btn-sm btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($uid); ?>-<?php echo e($cle); ?>-ajout"><i class="bi bi-plus-lg me-1"></i>Ajouter : <?php echo e($def['singulier']); ?></button>
                        <div class="collapse mt-3" id="<?php echo e($uid); ?>-<?php echo e($cle); ?>-ajout">
                            <form method="POST" action="<?php echo e(route('fiche.store', [$projet, $cle])); ?>" class="border rounded p-3">
                                <?php echo csrf_field(); ?>
                                <div class="row g-2">
                                    <?php $__currentLoopData = $def['champs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="<?php echo e($c['type'] === 'textarea' ? 'col-12' : 'col-md-4'); ?>">
                                            <?php echo $__env->make('projets.partials.volet_champ', ['c' => $c, 'valeur' => '', 'id' => $uid.'-'.$cle.'-n-'.$c['name']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <button class="btn btn-sm btn-primary mt-3">Enregistrer</button>
                            </form>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if (! ($lectureSeule)): ?>
        <?php $__currentLoopData = $lignes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ligne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="<?php echo e($uid); ?>-<?php echo e($cle); ?>-edit-<?php echo e($ligne->id); ?>" tabindex="-1">
                <div class="modal-dialog modal-lg"><div class="modal-content">
                    <form method="POST" action="<?php echo e(route('fiche.update', [$cle, $ligne->id])); ?>">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                        <div class="modal-header"><h5 class="modal-title">Modifier : <?php echo e($def['singulier']); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                        <div class="modal-body"><div class="row g-2">
                            <?php $__currentLoopData = $def['champs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="<?php echo e($c['type'] === 'textarea' ? 'col-12' : 'col-md-6'); ?>">
                                    <?php echo $__env->make('projets.partials.volet_champ', ['c' => $c, 'valeur' => $ligne->{$c['name']}, 'id' => $uid.'-'.$cle.'-e'.$ligne->id.'-'.$c['name']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div></div>
                        <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary">Enregistrer</button></div>
                    </form>
                </div></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /var/www/html/resources/views/projets/partials/volets.blade.php ENDPATH**/ ?>