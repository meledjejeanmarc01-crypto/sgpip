<?php $__env->startSection('page-title', 'Réformes'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="fw-bold m-0">Réformes</h5>
    <?php if(auth()->user()->hasRole(['administrateur','gestionnaire_projet'])): ?>
    <a href="<?php echo e(route('reformes.create')); ?>" class="btn btn-sm btn-brand"><i class="bi bi-plus-lg"></i> Nouvelle réforme</a>
    <?php endif; ?>
</div>
<form class="row g-2 mb-3">
    <div class="col-md-4"><input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control form-control-sm" placeholder="Rechercher (libellé)..."></div>
    <div class="col-md-3">
        <select name="statut" class="form-select form-select-sm">
            <option value="">Tous les statuts</option>
            <option value="demarree" <?php if(request('statut')=='demarree'): echo 'selected'; endif; ?>>Démarrée</option>
            <option value="en_cours" <?php if(request('statut')=='en_cours'): echo 'selected'; endif; ?>>En cours</option>
            <option value="achevee" <?php if(request('statut')=='achevee'): echo 'selected'; endif; ?>>Achevée</option>
        </select>
    </div>
    <div class="col-md-2"><button class="btn btn-sm btn-outline-secondary w-100">Filtrer</button></div>
</form>
<div class="card card-stat">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Intitulé</th><th>Structure</th><th>Axe</th><th>Statut</th><th>Période</th><th class="text-end">Actions</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reformes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reforme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><a href="<?php echo e(route('reformes.show', $reforme)); ?>" class="text-decoration-none"><?php echo e($reforme->libelle); ?></a></td>
                    <td><?php echo e($reforme->structure->libelle ?? '—'); ?></td>
                    <td><?php echo e($reforme->axe->libelle ?? '—'); ?></td>
                    <td><span class="badge bg-light text-dark border"><?php echo e(str_replace('_',' ',$reforme->statut)); ?></span></td>
                    <td><?php echo e($reforme->annee_debut); ?> - <?php echo e($reforme->annee_fin); ?></td>
                    <td class="text-end">
                        <a href="<?php echo e(route('reformes.show', $reforme)); ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i></a>
                        <?php if(auth()->user()->hasRole(['administrateur','gestionnaire_projet'])): ?>
                        <a href="<?php echo e(route('reformes.edit', $reforme)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></a>
                        <form action="<?php echo e(route('reformes.destroy', $reforme)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Confirmer la suppression de cette réforme ?');">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Aucune réforme enregistrée.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($reformes->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/reformes/index.blade.php ENDPATH**/ ?>