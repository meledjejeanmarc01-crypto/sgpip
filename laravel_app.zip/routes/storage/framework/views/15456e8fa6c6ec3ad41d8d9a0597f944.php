<?php $__env->startSection('title', 'Documents - SGSPIP'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">

    <div class="d-flex justify-content-between align-items-start mb-4 flex-wrap gap-2">
        <div>
            <h2 class="fw-bold mb-1"><i class="bi bi-file-earmark-text"></i> Documents</h2>
            <p class="text-muted mb-0">Vue d'ensemble des documents, tous projets confondus.</p>
        </div>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalDocument">
            <i class="bi bi-plus-lg"></i> Nouveau document
        </button>
    </div>

    <form method="GET" class="row g-2 mb-3">
        <div class="col-auto">
            <select name="projet_id" class="form-select" onchange="this.form.submit()">
                <option value="">Tous les projets</option>
                <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" <?php if(request('projet_id') == $p->id): echo 'selected'; endif; ?>><?php echo e($p->reference); ?> — <?php echo e($p->intitule); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php if(request('projet_id')): ?>
            <div class="col-auto"><a href="<?php echo e(route('documents.index')); ?>" class="btn btn-outline-secondary">Réinitialiser</a></div>
        <?php endif; ?>
    </form>

    <div class="card border-0 shadow-sm">
        <div class="card-body p-0">
            <?php if($documents->count()): ?>
                <table class="table mb-0 align-middle">
                    <thead class="table-light"><tr><th>Projet</th><th>Titre</th><th>Type</th><th>Extension</th><th>Ajouté par</th><th class="text-end">Action</th></tr></thead>
                    <tbody>
                    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="<?php echo e(route('projets.show', $doc->projet)); ?>" class="small"><?php echo e($doc->projet?->reference); ?></a></td>
                            <td><?php echo e($doc->titre); ?></td>
                            <td><?php echo e($doc->type ?? '—'); ?></td>
                            <td><span class="badge text-bg-light"><?php echo e(strtoupper($doc->extension ?? '')); ?></span></td>
                            <td><?php echo e($doc->ajoutePar?->name ?? '—'); ?></td>
                            <td class="text-end">
                                <a href="<?php echo e(route('documents.open', $doc)); ?>" target="_blank" class="btn btn-sm btn-outline-success" title="Ouvrir">
                                    <i class="bi bi-box-arrow-up-right"></i>
                                </a>
                                <a href="<?php echo e(route('documents.download', $doc)); ?>" class="btn btn-sm btn-outline-primary" title="Télécharger">
                                    <i class="bi bi-download"></i>
                                </a>
                                <form action="<?php echo e(route('documents.destroy', $doc)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Supprimer ?');">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-outline-danger" title="Supprimer"><i class="bi bi-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted p-4 mb-0">Aucun document trouvé. Utilisez le bouton « Nouveau document » ci-dessus, ou ajoutez-en un depuis la fiche d'un projet.</p>
            <?php endif; ?>
        </div>
        <div class="card-footer bg-white"><?php echo e($documents->links()); ?></div>
    </div>
</div>


<div class="modal fade" id="modalDocument" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="formDocument" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header"><h5 class="modal-title">Nouveau document</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="mb-2">
                        <label class="form-label">Projet</label>
                        <select id="documentProjetSelect" class="form-select" required>
                            <option value="">-- Sélectionner un projet --</option>
                            <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p->id); ?>"><?php echo e($p->reference); ?> — <?php echo e($p->intitule); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-2"><label class="form-label">Titre</label><input type="text" name="titre" class="form-control" required></div>
                    <div class="mb-2">
                        <label class="form-label">Type de document</label>
                        <select name="type_document_id" class="form-select" data-creer-url="<?php echo e(route('types-document.store')); ?>" data-creer-nom="Nom du nouveau type de document">
                            <option value="">-- Choisir --</option>
                            <?php $__currentLoopData = \App\Models\TypeDocument::orderBy('libelle')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($td->id); ?>"><?php echo e($td->libelle); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-2"><label class="form-label">Fichier (PDF, Word, Excel — 5 Mo max)</label><input type="file" name="fichier" class="form-control" accept=".pdf,.doc,.docx,.xls,.xlsx" required></div>
                    <div class="mb-2"><label class="form-label">Description</label><textarea name="description" class="form-control" rows="2"></textarea></div>
                </div>
                <div class="modal-footer"><button type="submit" class="btn btn-primary" id="btnDocumentSubmit" disabled>Ajouter</button></div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    document.getElementById('documentProjetSelect').addEventListener('change', function () {
        const form = document.getElementById('formDocument');
        const btn = document.getElementById('btnDocumentSubmit');
        if (this.value) {
            form.action = '/projets/' + this.value + '/documents';
            btn.disabled = false;
        } else {
            btn.disabled = true;
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/documents/index.blade.php ENDPATH**/ ?>