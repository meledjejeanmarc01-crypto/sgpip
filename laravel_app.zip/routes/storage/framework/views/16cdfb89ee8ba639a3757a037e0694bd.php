<?php $__env->startSection('page-title', 'Rapports'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="fw-bold m-0">Rapports de suivi</h5>
    <a href="<?php echo e(route('rapports.create')); ?>" class="btn btn-sm btn-brand"><i class="bi bi-plus-lg"></i> Nouveau rapport</a>
</div>
<div class="card card-stat">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Titre</th><th>Type</th><th>Projet</th><th>Auteur</th><th>Date</th><th class="text-end">Actions</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rapports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><a href="<?php echo e(route('rapports.show', $r)); ?>" class="text-decoration-none"><?php echo e($r->titre); ?></a></td>
                    <td><span class="badge bg-light text-dark border"><?php echo e(str_replace('_',' ',$r->type)); ?></span></td>
                    <td><?php echo e($r->projet->intitule ?? '—'); ?></td>
                    <td><?php echo e($r->utilisateur->prenom ?? ''); ?> <?php echo e($r->utilisateur->nom ?? ''); ?></td>
                    <td><?php echo e($r->date->format('d/m/Y')); ?></td>
                    <td class="text-end">
                        <?php if($r->fichier): ?><a href="<?php echo e(route('rapports.download', $r)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-download"></i></a><?php endif; ?>
                        <a href="<?php echo e(route('rapports.edit', $r)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-pencil"></i></a>
                        <form action="<?php echo e(route('rapports.destroy', $r)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Confirmer la suppression ?');">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Aucun rapport enregistré.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3"><?php echo e($rapports->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/rapports/index.blade.php ENDPATH**/ ?>