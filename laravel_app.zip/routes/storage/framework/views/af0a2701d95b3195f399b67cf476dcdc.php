
<?php $req = ($c['required'] ?? false); ?>
<label class="form-label small mb-1" for="<?php echo e($id); ?>"><?php echo e($c['label']); ?><?php if($req): ?> <span class="text-danger">*</span><?php endif; ?></label>
<?php if($c['type'] === 'textarea'): ?>
    <textarea id="<?php echo e($id); ?>" name="<?php echo e($c['name']); ?>" rows="2" class="form-control form-control-sm" <?php if($req): echo 'required'; endif; ?>><?php echo e($valeur); ?></textarea>
<?php elseif($c['type'] === 'select'): ?>
    <select id="<?php echo e($id); ?>" name="<?php echo e($c['name']); ?>" class="form-select form-select-sm" <?php if($req): echo 'required'; endif; ?>>
        <option value="">-- Choisir --</option>
        <?php $__currentLoopData = $c['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $lib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($val); ?>" <?php if((string) $valeur === (string) $val): echo 'selected'; endif; ?>><?php echo e($lib); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<?php elseif(isset($optionsProjet[$c['type']])): ?>
    
    <select id="<?php echo e($id); ?>" name="<?php echo e($c['name']); ?>" class="form-select form-select-sm" <?php if($req): echo 'required'; endif; ?>>
        <option value="">-- Choisir --</option>
        <?php $__currentLoopData = $optionsProjet[$c['type']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $lib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($val); ?>" <?php if((string) $valeur === (string) $val): echo 'selected'; endif; ?>><?php echo e($lib); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<?php elseif($c['type'] === 'year'): ?>
    <input id="<?php echo e($id); ?>" type="number" name="<?php echo e($c['name']); ?>" value="<?php echo e($valeur); ?>" min="2000" max="2100" class="form-control form-control-sm" <?php if($req): echo 'required'; endif; ?>>
<?php elseif($c['type'] === 'number'): ?>
    <input id="<?php echo e($id); ?>" type="number" step="0.01" min="0" <?php if(isset($c['max'])): ?> max="<?php echo e($c['max']); ?>" <?php endif; ?> name="<?php echo e($c['name']); ?>" value="<?php echo e($valeur); ?>" class="form-control form-control-sm" <?php if($req): echo 'required'; endif; ?>>
<?php else: ?>
    <input id="<?php echo e($id); ?>" type="text" name="<?php echo e($c['name']); ?>" value="<?php echo e($valeur); ?>" class="form-control form-control-sm" <?php if($req): echo 'required'; endif; ?>>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/projets/partials/volet_champ.blade.php ENDPATH**/ ?>