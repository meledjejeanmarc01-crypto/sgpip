<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Cahier des charges §6 : le consultant consulte sans pouvoir modifier.
 * Toute requête d'écriture (ou page de création / modification) lui est refusée,
 * sauf le changement de son propre mot de passe.
 */
class ConsultantLectureSeule
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if ($user && $user->role === 'consultant') {
            $nom = (string) $request->route()?->getName();
            $ecriture = ! $request->isMethodSafe();
            $pageEdition = (bool) preg_match('/\.(create|edit)$/', $nom);
            $exception = str_starts_with($nom, 'mot-de-passe.') || $nom === 'notifications.lues';

            if (($ecriture || $pageEdition) && ! $exception) {
                abort(403, "Votre profil de consultant ne permet que la consultation.");
            }
        }

        return $next($request);
    }
}
