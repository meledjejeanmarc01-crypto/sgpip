<?php

namespace App\Http\Controllers;

use App\Models\Bailleur;
use App\Models\Decaissement;
use App\Models\Financement;
use App\Support\CoherenceFinanciere;
use Illuminate\Http\Request;

class DecaissementController extends Controller
{
    public function index(Request $request)
    {
        $decaissements = Decaissement::with(['bailleur', 'financement.projet'])
            ->when($request->q, fn ($q) => $q->where('reference', 'like', "%{$request->q}%"))
            ->orderByDesc('date')
            ->paginate(15)
            ->withQueryString();
        return view('decaissements.index', compact('decaissements'));
    }

    public function create()
    {
        [$bailleurs, $financements] = $this->referenceData();
        return view('decaissements.create', compact('bailleurs', 'financements'));
    }

    public function store(Request $request)
    {
        $data = $this->validateData($request);

        // Règle : financé > décaissé > dépensé.
        $variations = [];
        CoherenceFinanciere::ajuster($variations, CoherenceFinanciere::projetDuFinancement($data['financement_id'] ?? null), 'D', (float) $data['montant']);
        CoherenceFinanciere::verifier($variations, 'montant');

        Decaissement::create($data);
        return redirect()->route('decaissements.index')->with('success', 'Décaissement enregistré avec succès.');
    }

    public function edit(Decaissement $decaissement)
    {
        [$bailleurs, $financements] = $this->referenceData();
        return view('decaissements.edit', compact('decaissement', 'bailleurs', 'financements'));
    }

    public function update(Request $request, Decaissement $decaissement)
    {
        $data = $this->validateData($request, $decaissement->id);

        // Règle : financé > décaissé > dépensé (retrait de l'ancien montant, ajout du nouveau).
        $variations = [];
        CoherenceFinanciere::ajuster($variations, CoherenceFinanciere::projetDuFinancement($decaissement->financement_id), 'D', -(float) $decaissement->montant);
        CoherenceFinanciere::ajuster($variations, CoherenceFinanciere::projetDuFinancement($data['financement_id'] ?? null), 'D', (float) $data['montant']);
        CoherenceFinanciere::verifier($variations, 'montant');

        $decaissement->update($data);
        return redirect()->route('decaissements.index')->with('success', 'Décaissement mis à jour.');
    }

    public function destroy(Decaissement $decaissement)
    {
        $variations = [];
        CoherenceFinanciere::ajuster($variations, CoherenceFinanciere::projetDuFinancement($decaissement->financement_id), 'D', -(float) $decaissement->montant);
        if ($erreur = CoherenceFinanciere::erreur($variations)) {
            return back()->with('error', 'Impossible de supprimer : '.$erreur);
        }

        $decaissement->delete();
        return back()->with('success', 'Décaissement supprimé.');
    }

    private function referenceData(): array
    {
        return [
            Bailleur::orderBy('nom')->get(),
            Financement::with('projet')->orderByDesc('date')->get(),
        ];
    }

    private function validateData(Request $request, ?int $ignoreId = null): array
    {
        return $request->validate([
            'montant' => 'required|numeric|min:0',
            'date' => 'required|date',
            'reference' => 'required|string|max:50|unique:decaissements,reference,'.$ignoreId,
            'bailleur_id' => 'required|exists:bailleurs,id',
            'financement_id' => 'nullable|exists:financements,id',
        ]);
    }
}
