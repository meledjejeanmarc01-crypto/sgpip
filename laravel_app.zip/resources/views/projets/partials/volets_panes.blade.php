{{-- Panneaux des volets de la fiche projet (un panneau par onglet). À inclure une fois dans <div class="tab-content"> --}}
@php
    $court = [
        'beneficiaires' => 'Bénéficiaires',
        'emplois' => "Opportunités d'emploi",
        'comites' => 'Cadre de gestion',
        'charges' => 'Charges récurrentes',
        'budgets' => 'Programmation budgétaire',
        'marches' => 'Marchés',
        'echeanciers' => 'Échéancier AE-CP',
        'criteres' => "Critères d'appréciation",
        'ventilations' => 'Ventilation interne',
        'plan_decaissement' => 'Plan de décaissement',
        'plan_global' => 'Mise en œuvre (global)',
        'plan_detaille' => 'Mise en œuvre (détaillé)',
        'plan_travail' => 'Plan de travail annuel',
        'demande_financement' => 'Demande de financement',
        'previsions_valeur' => 'Prévisions en valeur',
        'programmation_lf' => 'Programmation LF',
    ];
@endphp
@php
    $defs = \App\Support\FicheVolets::definitions();
    $marchesProjet = $projet->marches()->orderBy('id')->get();
    $financementsProjet = $projet->financements()->with('bailleur')->orderBy('id')->get();
    $activitesProjet = $projet->activites()->orderBy('id')->get();
    $composantesProjet = $projet->composantes()->orderBy('id')->get();
    $lectureSeule = optional(auth()->user())->role === 'consultant';

    // Listes proposées dans les formulaires (clé = type de champ).
    $optionsProjet = [
        'marche' => $marchesProjet->mapWithKeys(fn ($m) => [$m->id => $m->objet])->all(),
        'financement' => $financementsProjet->mapWithKeys(fn ($f) => [$f->id => $f->reference.' — '.(optional($f->bailleur)->nom ?? 'sans bailleur')])->all(),
        'activite' => $activitesProjet->mapWithKeys(fn ($a) => [$a->id => $a->intitule])->all(),
        'composante' => $composantesProjet->mapWithKeys(fn ($k) => [$k->id => $k->libelle])->all(),
    ];
    $elementsParScope = ['marche' => $marchesProjet, 'financement' => $financementsProjet, 'activite' => $activitesProjet, 'composante' => $composantesProjet];
    $messageManque = [
        'marche' => "un marché (onglet « Marchés »)",
        'financement' => "un financement (onglet « Financements »)",
        'activite' => "une activité (onglet « Activités & tâches »)",
        'composante' => "une composante (onglet « Composantes »)",
    ];

    $nombre = function ($v, $c) {
        $texte = rtrim(rtrim(number_format((float) $v, 2, ',', ' '), '0'), ',');
        return ($c['unite'] ?? '') === '%' ? $texte.' %' : $texte;
    };
    $formater = function ($c, $ligne) use ($optionsProjet, $nombre) {
        $v = $ligne->{$c['name']} ?? null;
        if ($v === null || $v === '') { return '—'; }
        if ($c['type'] === 'select') { return $c['options'][$v] ?? $v; }
        if (isset($optionsProjet[$c['type']])) { return $optionsProjet[$c['type']][$v] ?? '—'; }
        if ($c['type'] === 'year') { return $v; }
        if ($c['type'] === 'number') {
            return str_starts_with($c['name'], 'taux_') ? number_format((float) $v, 0, ',', ' ').' %' : $nombre($v, $c);
        }
        return \Illuminate\Support\Str::limit($v, 60);
    };
    $toutesLignes = [];
@endphp
@foreach($court as $cle => $titreCourt)
    @php
        $def = $defs[$cle];
        $lignes = $def['scope'] === 'projet'
            ? $def['model']::where('projet_id', $projet->id)->orderBy('id')->get()
            : $def['model']::whereIn($def['scope'].'_id', $elementsParScope[$def['scope']]->pluck('id'))->orderBy('id')->get();
        $toutesLignes[$cle] = $lignes;
        $champsAffiches = collect($def['champs'])->whereIn('name', $def['colonnes'])->sortBy(fn ($c) => array_search($c['name'], $def['colonnes']))->values()
            ->concat(collect($def['calcules'] ?? []));
        $manque = collect($def['champs'])->first(fn ($c) => isset($optionsProjet[$c['type']]) && empty($optionsProjet[$c['type']]));
        $totaux = $def['totaux'] ?? [];
    @endphp
    <div class="tab-pane fade" id="volet-{{ $cle }}">
        <div class="card card-stat p-4 mb-3">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                <div>
                    <h5 class="fw-bold mb-1">{{ $def['titre'] }} <span class="badge" style="background:#FF8200">{{ $lignes->count() }}</span></h5>
                    <p class="text-muted small mb-0">{{ $def['aide'] }}</p>
                </div>
                @unless($lectureSeule || $manque)
                    <button class="btn btn-sm btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#volet-{{ $cle }}-ajout"><i class="bi bi-plus-lg me-1"></i>Ajouter : {{ $def['singulier'] }}</button>
                @endunless
            </div>

            @unless($lectureSeule)
                @if($manque)
                    <div class="alert alert-info py-2">Enregistrez d'abord {{ $messageManque[$manque['type']] }} pour pouvoir saisir ce volet.</div>
                @else
                    <div class="collapse mb-3" id="volet-{{ $cle }}-ajout">
                        <form method="POST" action="{{ route('fiche.store', [$projet, $cle]) }}" class="border rounded p-3 bg-light">
                            @csrf
                            <div class="row g-2">
                                @foreach($def['champs'] as $c)
                                    <div class="{{ $c['type'] === 'textarea' ? 'col-12' : 'col-md-4' }}">
                                        @include('projets.partials.volet_champ', ['c' => $c, 'valeur' => '', 'id' => 'volet-'.$cle.'-n-'.$c['name']])
                                    </div>
                                @endforeach
                            </div>
                            <button class="btn btn-sm btn-primary mt-3">Enregistrer</button>
                        </form>
                    </div>
                @endif
            @endunless

            {{-- Tableau de synthèse (lignes x années), comme dans le canevas --}}
            @if(isset($def['matrice']) && $lignes->isNotEmpty())
                @php
                    $mx = $def['matrice'];
                    $typeLigne = collect($def['champs'])->firstWhere('name', $mx['ligne'])['type'];
                    $annees = $lignes->pluck($mx['colonne'])->unique()->sort()->values();
                    $groupes = $lignes->groupBy($mx['ligne']);
                @endphp
                <div class="table-responsive mb-3">
                    <table class="table table-sm table-bordered align-middle mb-0 text-end">
                        <thead class="table-light"><tr>
                            <th class="text-start">{{ $mx['titre'] }}</th>
                            @foreach($annees as $a)<th>{{ $a }}</th>@endforeach
                            <th>Total</th>
                        </tr></thead>
                        <tbody>
                        @foreach($groupes as $idLigne => $groupe)
                            <tr>
                                <td class="text-start">{{ $optionsProjet[$typeLigne][$idLigne] ?? '—' }}</td>
                                @foreach($annees as $a)<td>{{ number_format((float) $groupe->where($mx['colonne'], $a)->sum($mx['valeur']), 0, ',', ' ') }}</td>@endforeach
                                <td class="fw-semibold">{{ number_format((float) $groupe->sum($mx['valeur']), 0, ',', ' ') }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                        <tfoot class="table-light fw-semibold"><tr>
                            <td class="text-start">Total</td>
                            @foreach($annees as $a)<td>{{ number_format((float) $lignes->where($mx['colonne'], $a)->sum($mx['valeur']), 0, ',', ' ') }}</td>@endforeach
                            <td>{{ number_format((float) $lignes->sum($mx['valeur']), 0, ',', ' ') }}</td>
                        </tr></tfoot>
                    </table>
                </div>
            @endif

            {{-- Fiche d'évaluation des charges récurrentes : synthèse par année (canevas, Programmation, section 5) --}}
            @if($cle === 'charges' && $lignes->isNotEmpty())
                @include('projets.partials.synthese_charges', ['lignes' => $lignes])
            @endif

            @if($lignes->isEmpty())
                <p class="text-muted fst-italic mb-0">Aucune ligne enregistrée.</p>
            @else
                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0">
                        <thead><tr>
                            @foreach($champsAffiches as $c)<th>{{ $c['label'] }}</th>@endforeach
                            @unless($lectureSeule)<th style="width:110px"></th>@endunless
                        </tr></thead>
                        <tbody>
                        @foreach($lignes as $ligne)
                            <tr>
                                @foreach($champsAffiches as $c)<td>{{ $formater($c, $ligne) }}</td>@endforeach
                                @unless($lectureSeule)
                                <td class="text-end text-nowrap">
                                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#volet-{{ $cle }}-edit-{{ $ligne->id }}" title="Modifier"><i class="bi bi-pencil"></i></button>
                                    <form method="POST" action="{{ route('fiche.destroy', [$cle, $ligne->id]) }}" class="d-inline" onsubmit="return confirm('Supprimer cette ligne ?');">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-sm btn-outline-danger" title="Supprimer"><i class="bi bi-trash"></i></button>
                                    </form>
                                </td>
                                @endunless
                            </tr>
                        @endforeach
                        </tbody>
                        @if($totaux)
                        <tfoot class="table-light fw-semibold"><tr>
                            @foreach($champsAffiches as $i => $c)
                                <td>@if($i === 0) Total @elseif(in_array($c['name'], $totaux)) {{ $nombre($lignes->sum(fn ($l) => (float) $l->{$c['name']}), $c) }} @endif</td>
                            @endforeach
                            @unless($lectureSeule)<td></td>@endunless
                        </tr></tfoot>
                        @endif
                    </table>
                </div>
            @endif
        </div>
    </div>
@endforeach

{{-- Fenêtres de modification (hors des panneaux pour éviter tout problème d'affichage) --}}
@unless($lectureSeule)
    @foreach($court as $cle => $titreCourt)
        @php $def = $defs[$cle]; @endphp
        @foreach($toutesLignes[$cle] as $ligne)
            <div class="modal fade" id="volet-{{ $cle }}-edit-{{ $ligne->id }}" tabindex="-1">
                <div class="modal-dialog modal-lg"><div class="modal-content">
                    <form method="POST" action="{{ route('fiche.update', [$cle, $ligne->id]) }}">
                        @csrf @method('PUT')
                        <div class="modal-header"><h5 class="modal-title">Modifier : {{ $def['singulier'] }}</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                        <div class="modal-body"><div class="row g-2">
                            @foreach($def['champs'] as $c)
                                <div class="{{ $c['type'] === 'textarea' ? 'col-12' : 'col-md-6' }}">
                                    @include('projets.partials.volet_champ', ['c' => $c, 'valeur' => $ligne->{$c['name']}, 'id' => 'volet-'.$cle.'-e'.$ligne->id.'-'.$c['name']])
                                </div>
                            @endforeach
                        </div></div>
                        <div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary">Enregistrer</button></div>
                    </form>
                </div></div>
            </div>
        @endforeach
    @endforeach
@endunless
